<!DOCTYPE html>
<html>
<head>
    <title>Area Calculator Result</title>
</head>
<body>
    <h1>Area Calculator Result</h1>
    <p>Shape: {{ $shape }}</p>
    <p>Area: {{ $area }}</p>
    <a href="/calculator">Calculate Another</a>
</body>
</html>
